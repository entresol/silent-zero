/* SPDX-License-Identifier: BSD-3-Clause */
/**
 *  \file   mdio.h
 *
 *  \brief  MDIO APIs and macros.
 *
 *   This file contains the driver API prototypes and macro definitions.
 */

/*
* Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/
*/
/*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*    Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
*
*    Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the
*    documentation and/or other materials provided with the
*    distribution.
*
*    Neither the name of Texas Instruments Incorporated nor the names of
*    its contributors may be used to endorse or promote products derived
*    from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*/

#pragma once

#include "hw/hw_mdio.h"

#ifdef __cplusplus
extern "C" {
#endif
    /*****************************************************************************/
    /*
    ** Structure to save CPSW context
    */
    typedef struct mdioContext {
        unsigned int mdioCtrl;
    } MDIOCONTEXT;

    /*
    ** Prototypes for the APIs
    */
    extern unsigned int MDIOPhyAliveStatusGet(unsigned int baseAddr);
    extern unsigned int MDIOPhyLinkStatusGet(unsigned int baseAddr);
    extern void MDIOInit(unsigned int baseAddr, unsigned int mdioInputFreq,
                         unsigned int mdioOutputFreq);
    extern unsigned int MDIOPhyRegRead(unsigned int baseAddr, unsigned int phyAddr,
                                       unsigned int regNum, volatile unsigned short *dataPtr);
    extern void MDIOPhyRegWrite(unsigned int baseAddr, unsigned int phyAddr,
                                unsigned int regNum, unsigned short RegVal);
    extern void MDIOContextSave(unsigned int baseAddr, MDIOCONTEXT *contextPtr);
    extern void MDIOContextRestore(unsigned int baseAddr, MDIOCONTEXT *contextPtr);
#ifdef __cplusplus
}
#endif
